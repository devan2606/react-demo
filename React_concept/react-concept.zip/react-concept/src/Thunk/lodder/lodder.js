import React from 'react';
import './Lodder.css'

const loader = () => (
  <div id="loader">
    <div id="bouncer1" />
    <div id="bouncer2" />
  </div>
)

export default loader;