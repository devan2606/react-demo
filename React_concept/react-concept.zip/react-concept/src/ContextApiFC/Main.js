import React  from "react";
import SecondComponent from "./SecondComponent";



export const Main = () => {
  return (
    <div>
      <SecondComponent />
    </div>
  );
}

